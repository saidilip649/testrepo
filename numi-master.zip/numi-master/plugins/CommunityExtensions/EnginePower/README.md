# Engine power Extension for Numi

## What is this extension for? :mag_right:

This extension allows you to easily transform engine power from kw to hp and vice versa

## Installation :floppy_disk:

Simply download the .js file to your numi extensions directory.

## How to use it :wrench:
```
10 kw in hp
10 hp in kw
```

## Example :memo:
![extensionDemonstration](SS.png)
