# Find loarithm Extension for Numi

## What is this extension for? :mag_right:

This extension allows you to easily calculate a logarithm with any base

## Installation :floppy_disk:

Simply download the .js file to your numi extensions directory.


## How to use it :wrench:

You can get log base 2 like follows:

`log 4`

Or any base can be specified as first parameter:

`log 2;4`