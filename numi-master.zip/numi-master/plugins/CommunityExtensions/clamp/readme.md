# Clamp extension for Numi

## What is this extension for? :mag_right:

This extension allows you to limit the minimum and the maximum number range.

## Installation :floppy_disk:

Simply download the .js file to your numi extensions directory.

## How to use it :wrench:

```
clamp(15;3;7) // 7
clamp(1;3;7) // 3
clamp(5;3;7) // 5

```       